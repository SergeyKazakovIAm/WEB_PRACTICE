# ATLAS UI Kit — Help Desk

Минимальная проверяемая дизайн-система: токены, три режима темы (auto / light / dark), плотность (обычная / компактная), компоненты с состояниями. Без Bootstrap/Tailwind, без `!important` (кроме общепринятого блока `prefers-reduced-motion`), без HEX в `components.css`.

**Запуск:** `python -m http.server 5500` → http://localhost:5500
**Демо-страница:** _вставьте ссылку на GitHub Pages / публикацию_ · **Репозиторий:** _вставьте ссылку на GitHub_

## Скриншоты (`screenshots/`)
`01_light.png` · `02_dark.png` · `03_dark_compact.png` · `04_mobile_320.png` (+ `05_light_compact.png`, `06_dark_mobile_320.png`)

## Диагностика и план (этап 0)
**Проблема:** в стартовом проекте была только светлая тема, не было `secondary`/`ghost`, полей, уведомлений и логики переключателя; одни и те же решения грозили дублироваться разными значениями.
**План:** тёмная тема через семантические роли → `theme.js` → кнопки → поля и alert → плотность и warning → проверки.

## Архитектура токенов: primitive → semantic → component
| Уровень | Примеры | Файл |
|---|---|---|
| Примитивы | `--base-blue-700`, `--base-slate-950`, `--space-*`, `--font-size-*` | `tokens.css` |
| Семантика | `--color-primary`, `--color-text`, `--color-error-bg`, `--color-warning`, `--color-disabled-bg` | `tokens.css` (светлая — `:root`, тёмная — 2 ветви) |
| Компоненты | `--button-bg-primary`, `--control-border`, `--alert-padding`, `--component-gap` | `tokens.css` |

**Цепочки (все реальные):**
1. `--base-blue-700` → `--color-primary` → `--button-bg-primary` → `.button--primary` (в dark `--color-primary` = `#2a66b8`, класс не меняется).
2. `--color-border-control` → `--control-border` → `.input`, `.select` (и `--button-border-secondary` → `.button--secondary`).
3. `--color-error` → `--control-border-invalid` → `.input[aria-invalid="true"]`; та же роль → `.alert--error`, `.field__error`.
4. `--color-warning` / `--color-warning-bg` → `.alert--warning` (светлая и тёмная палитры).

**Тёмная тема:** `@media (prefers-color-scheme: dark) { :root:not([data-theme]) {…} }` — только для режима auto; `:root[data-theme="dark"] {…}` — ручной выбор; обе ветви с `color-scheme: dark`. `data-theme="light"` не попадает ни в одну тёмную ветвь, поэтому остаётся светлой даже при тёмной ОС.
**Плотность:** `:root[data-density="compact"]` переопределяет 9 компонентных токенов (`--button-height`, `--control-height`, `--button-padding-inline`, `--control-padding-inline`, `--component-gap`, `--alert-padding`, `--alert-gap`, `--button-font-size`, `--control-font-size`); цветов не касается, поэтому тема и плотность независимы.

## Компоненты
- **Кнопки:** `primary`, `secondary`, `ghost`; состояния hover / active / `:focus-visible` (общее правило, не перекрыто) / disabled.
- **Поля:** `.input`, `.select`; `::placeholder`, `:focus`, `:disabled`, `[aria-invalid="true"]` (2px рамка + текст ошибки через `aria-describedby="email-error"`).
- **Alert:** `info`, `success`, `error`, `warning` — символ + заголовок + текст, цвет не единственный признак; длинный текст переносится (`overflow-wrap: anywhere`).

## Таблица проверок
| Условие | Результат |
|---|---|
| auto + ОС dark | фон `#101923`, `data-theme` отсутствует — ✔ |
| light при ОС dark | фон `#f6f8fc` — ✔ |
| dark при ОС light | фон `#101923` — ✔ |
| Перезагрузка | `atlas-theme` и `atlas-density` восстанавливаются — ✔ |
| Неверное значение в localStorage | откат к `auto` / `normal` — ✔ |
| Плотность ↔ тема | независимы (разные атрибуты и ключи) — ✔ |
| Высота кнопки normal / compact | 44 px / 36 px — ✔ |
| 320, 375, 768, 1024, 1440 px × 4 сочетания | горизонтального скролла нет — ✔ |
| Tab / Shift+Tab | видимый outline 3 px на кнопках и полях — ✔ |
| hover / active кнопок | три разных значения фона в обеих темах — ✔ |
| Ошибка поля | красная 2px рамка + текст ошибки — ✔ |
| `grep` HEX в `components.css` | 0 совпадений — ✔ |

**Контраст (WCAG 2.2 AA, измерено по computed-стилям), light / dark:** текст 14.9 / 16.0; muted 5.8 / 9.7; primary-кнопка 7.5 / 5.7; info 6.4 / 8.8; success 5.5 / 9.2; error 6.7 / 8.1; warning 6.3 / 8.6; граница контролов на поверхности 8.6 / 8.2 (≥ 3:1), у secondary-кнопки 3.4 / 6.1.

## Ответы
**а) Почему плотность задаётся компонентными токенами?** Размеры компонентов зависят от одних и тех же токенов, поэтому один блок `[data-density="compact"]` меняет все кнопки, поля и группы сразу, без копий `.button`/`.input` и конфликтов с темой.
**б) Почему тёмная тема не хранит цвета внутри `.button`?** Класс ссылается на роль (`--color-primary`), а значение роли меняется в токенах. Новая тема или смена бренда не требует правки компонентов, и нет риска забыть отдельное состояние.

## Как подключить ко второй странице
Подключить `tokens.css`, `components.css`, `theme.js`; использовать классы `.button--*`, `.input`, `.select`, `.alert--*`; при необходимости добавить `#theme-select` и `#density-select` (в `theme.js` — проверка на `null` для страниц без переключателей).

## Известное ограничение
Тема применяется скриптом с `defer`, поэтому при ручном выборе возможна вспышка до применения; решение — маленький синхронный скрипт в `<head>`, который выставляет `data-theme`.
