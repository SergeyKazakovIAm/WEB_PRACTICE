const root = document.documentElement;
const themeSelect = document.querySelector('#theme-select');
const densitySelect = document.querySelector('#density-select');
const demoAction = document.querySelector('#demo-action');
const demoFeedback = document.querySelector('#demo-feedback');

const THEME_KEY = 'atlas-theme';
const DENSITY_KEY = 'atlas-density';
const THEMES = ['auto', 'light', 'dark'];
const DENSITIES = ['normal', 'compact'];

function readSetting(key, allowed, fallback) {
  try {
    const value = localStorage.getItem(key);
    return allowed.includes(value) ? value : fallback;
  } catch (error) {
    return fallback;
  }
}

function saveSetting(key, value) {
  try { localStorage.setItem(key, value); } catch (error) {  }
}

function applyTheme(choice) {
  const value = THEMES.includes(choice) ? choice : 'auto';
  if (value === 'auto') root.removeAttribute('data-theme');
  else root.dataset.theme = value;
  themeSelect.value = value;
  return value;
}

function applyDensity(choice) {
  const value = DENSITIES.includes(choice) ? choice : 'normal';
  if (value === 'normal') root.removeAttribute('data-density');
  else root.dataset.density = value;
  densitySelect.value = value;
  return value;
}

applyTheme(readSetting(THEME_KEY, THEMES, 'auto'));
applyDensity(readSetting(DENSITY_KEY, DENSITIES, 'normal'));

themeSelect.addEventListener('change', () => saveSetting(THEME_KEY, applyTheme(themeSelect.value)));
densitySelect.addEventListener('change', () => saveSetting(DENSITY_KEY, applyDensity(densitySelect.value)));

demoAction.addEventListener('click', () => {
  demoFeedback.textContent = 'Демонстрация: действие выполнено, новая заявка создана.';
});
